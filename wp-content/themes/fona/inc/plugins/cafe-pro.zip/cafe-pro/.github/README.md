# TemplateKit

## 1. Source of a template

### 1.1 `remote` templates

When you open TemplateKit, templates are automatically retrieved from [rest.cleveraddon.com](https://rest.cleveraddon.com/) server via a REST API.

#### HOW TO CREATE A REMOTE TEMPLATE?

Same as creating any Elementor template. The difference is we have to specify categories and tags for each template so that TemplateKit knows how to classify templates.

To add categories and tags to templates, exit Elementor live editor mode and enter classic editor mode of WordPress. There will be `Categories` and `Tags` metaboxes on the right of the editor screen.

**Please note that remote templates will be cached in transients in client sites. Make sure to delete transients if you want to see newly added templates**.

### 1.2 `local` templates

These templates are included in the plugin by default. You can add templates by:

* **Step 1**: Choose or make a folder `src/templatekit/templates/{$template_type}/{$template_category}/{$template_slug}`.

    - `$template_type` is type of the template. E.g., `home-pages`. You can't create more template types, there are only three allowed types: `home-pages`, `sub-pages` or `sections`.
    - `$template_category` is category of the template. You can create as many as category you want.
    - `$template_slug` is slug of the template.

    All folder names must be lowercase, accepted characters are `[a-z], [1-9]` and `-`.

* **Step 2**: Export your template into a file named `content.json` and put it inside the created folder from Step 1.
* **Step 3**: Create a `meta.txt` file which contains metadata of the template. This is similar to how WordPress defines page template files. For example:
```
Template Name: Ultra Beam
Keywords: creative, agency, kanye west
```
Template Name is for displaying. Keywords are for searching and classifying.

* **Step 4**: Make a `thumb.jpg` and `preview.jpg`, put them inside the folder created from Step 1. These picture is for previewing purpose.

* **Done**: Your template will be listed automatically and ready to be used.
