# Clever-Addons-for-Elementor

Clever Addons is Fully Customizable and Ultimate elements library for Elementor WordPress Page Builder. Lots of useful and premium elements to complete your website quickly. Stunning design and neat and clean code. Option to enable/disable certain elements to improve page loading. No extra resources to slow down your website.


## Elements types
- [ ] accordion
- [ ] article
- [ ] author
- [ ] blog
- [ ] button
- [ ] countdown
- [ ] counter
- [ ] feature
- [ ] form
- [ ] gallery
- [ ] google- [] map
- [ ] list
- [ ] logos
- [ ] menu
- [ ] person
- [ ] pricing
- [ ] process
- [ ] product
- [ ] progressbar
- [ ] project
- [ ] schedule
- [ ] slider
- [ ] social
- [ ] tabs
- [ ] testimonial
- [ ] text
- [ ] timeline
- [ ] video
- [ ] webinar

## WooCommerce Elements

- [ ] Product Deal and Products Tabs 
- [ ] Products Deals 
- [ ] Product Carousel 2 
- [ ] Product Carousel 1 
- [ ] Products Grid With Banner 
- [ ] Product Grid 
- [ ] Products Grid with Category Tabs 
- [ ] Product Grid Tabs 
- [ ] Products Carousel with Category Tabs 
- [ ] Products Carousel Tabs 
- [ ] Product Carousel 
- [ ] Product Categories Grid 
