# Change Logs

## Version 1.0.5 - September 13, 2019

- Fixed menu item settings disappeared because of Elementor version 2.7.0 update

## Version 1.0.4 - September 10, 2019

- Fixed duplicate menu CSS.
- Fixed menu toggle hidden on mobile.
- Fixed conflicts with Elementor Nav Menu Widget.

## Version 1.0.3 - June 3, 2019

- Recover mistakenly deleted code.

## Version 1.0.2 - June 3, 2019

- Fixed server overload because of rewrite rules were not flushed properly.

## Version 1.0.1 - May 20, 2019

- Fixed horizontal menubar layout.
- Fixed conflicts with free version.
- Fixed 'the_content' not found error.

## Version 1.0.0 - April 06, 2019

- Initial Release
